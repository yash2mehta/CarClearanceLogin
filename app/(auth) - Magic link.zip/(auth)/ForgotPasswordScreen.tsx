import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window'); // Get screen dimensions

const ForgotPasswordScreen = () => {
  const router = useRouter();

  return (
    <View style={styles.container}>
      {/* Back Button */}
      <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
        <Ionicons name="chevron-back" size={24} color="black" />
      </TouchableOpacity>

      {/* Title */}
      <Text style={styles.header}>New Password</Text>

      {/* Password Fields */}
      <View style={styles.formContainer}>
        <Text style={styles.label}>Enter new password:</Text>
        <TextInput style={styles.input} placeholder="••••••••" secureTextEntry={true} placeholderTextColor="#A0A0A0" />

        {/* ✅ Added More Space Below First Password Field */}
        <View style={{ height: height * 0.03 }} /> 

        <Text style={styles.label}>Confirm password:</Text>
        <TextInput style={styles.input} placeholder="••••••••" secureTextEntry={true} placeholderTextColor="#A0A0A0" />
      </View>

      {/* ✅ Increased Bottom Spacing for "Save" Button */}
      <View style={{ height: height * 0.06 }} /> 

      {/* Save Button */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Save</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: width * 0.05,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  backButton: {
    position: 'absolute',
    top: height * 0.06, // Adjusts dynamically
    left: width * 0.05,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    marginTop: height * 0.06,
    marginBottom: height * 0.05,
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 5,
    color: '#000',
  },
  input: {
    height: 45,
    backgroundColor: '#F2F2F2',
    borderRadius: 10,
    paddingHorizontal: 12,
    fontSize: 14,
  },
  button: {
    backgroundColor: '#8A2BE2',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 10,
    elevation: 3,
    marginBottom: height * 0.08, // ✅ Increased bottom spacing
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default ForgotPasswordScreen;
