import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { auth } from '@/lib/firebaseConfig';
import { sendEmailVerification } from 'firebase/auth';

const { width, height } = Dimensions.get('window');

const OTPScreen = () => {
  const router = useRouter();
  const { email } = useLocalSearchParams(); // ✅ Get email passed from SignUpScreen
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [verified, setVerified] = useState(false);
  const [loading, setLoading] = useState(false);

  // ✅ Check if the email is verified every 3 seconds
  useEffect(() => {
    const interval = setInterval(async () => {
      await auth.currentUser?.reload();
      if (auth.currentUser?.emailVerified) {
        setVerified(true);
        clearInterval(interval);
        Alert.alert('Success', 'Your email has been verified!');
        router.push('/(auth)/home'); // ✅ Redirect to home after verification
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // ✅ Manually refresh verification status
  const handleCheckVerification = async () => {
    setLoading(true);
    await auth.currentUser?.reload();
    if (auth.currentUser?.emailVerified) {
      setVerified(true);
      Alert.alert('Success', 'Your email has been verified!');
      router.push('/(auth)/home');
    } else {
      Alert.alert('Pending', 'Your email is still not verified. Check your inbox.');
    }
    setLoading(false);
  };

  // ✅ Resend verification email
  const handleResendOTP = async () => {
    if (!auth.currentUser) return;
    try {
      await sendEmailVerification(auth.currentUser);
      Alert.alert('Sent', 'A new verification email has been sent.');
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  return (
    <View style={styles.container}>
      {/* OTP Header Text */}
      <Text style={styles.header}>We have sent you an OTP via your email</Text>

      {/* OTP Boxes */}
      <View style={styles.otpContainer}>
        {otp.map((digit, index) => (
          <TextInput
            key={index}
            style={styles.otpBox}
            keyboardType="number-pad"
            maxLength={1}
            value={digit}
            editable={false} // ✅ Disable manual OTP input (Email link is used instead)
          />
        ))}
      </View>

      {/* Resend & Edit Email Options */}
      <View style={styles.optionContainer}>
        <TouchableOpacity onPress={() => router.push('/(auth)/SignUpScreen')}>
          <Text style={styles.optionText}>Key-ed in the wrong email? <Text style={styles.optionLink}>Edit Email</Text></Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={handleResendOTP}>
          <Text style={styles.optionText}>Didn't receive OTP? <Text style={styles.optionLink}>Send Again</Text></Text>
        </TouchableOpacity>
      </View>

      {/* Submit & Refresh Buttons */}
      <View style={styles.bottomContainer}>
        <TouchableOpacity style={styles.button} onPress={handleCheckVerification} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Checking...' : 'Submit'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: width * 0.08,
    backgroundColor: '#fff',
    justifyContent: 'center',
  },
  header: {
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'left',
    marginBottom: height * 0.02,
  },
  otpContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: height * 0.04,
  },
  otpBox: {
    width: width * 0.12,
    height: width * 0.12,
    borderWidth: 1,
    borderColor: '#A0A0A0',
    textAlign: 'center',
    fontSize: 18,
    borderRadius: 5,
  },
  optionContainer: {
    alignItems: 'left',
    marginBottom: height * 0.05,
  },
  optionText: {
    fontSize: 14,
    color: '#333',
    marginBottom: 4,
  },
  optionLink: {
    color: '#8A2BE2',
    fontWeight: 'bold',
  },
  bottomContainer: {
    justifyContent: 'flex-end',
    paddingBottom: height * 0.05,
  },
  button: {
    backgroundColor: '#8A2BE2',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 10,
    elevation: 3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default OTPScreen;