import React from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import { useRouter } from 'expo-router';

const { width, height } = Dimensions.get('window'); // Get screen width & height

const LoginScreen = () => {
  const router = useRouter();

  return (
    <View style={styles.container}>
      {/* Form Inputs (Lowered using marginTop) */}
      <View style={styles.formContainer}>
        <Text style={styles.label}>Email Address:</Text>
        <TextInput style={styles.input} placeholder="e.g. hello@email.com" placeholderTextColor="#A0A0A0" />

        <Text style={styles.label}>Phone Number:</Text>
        <TextInput style={styles.input} placeholder="+65 9XXX XXXX" placeholderTextColor="#A0A0A0" keyboardType="phone-pad" />

        <Text style={styles.label}>Password:</Text>
        <TextInput style={styles.input} placeholder="••••••••" placeholderTextColor="#A0A0A0" secureTextEntry={true} />

        <TouchableOpacity onPress={() => router.push('/(auth)/ForgotPasswordScreen')}>
          <Text style={styles.forgot}>Forgot Password?</Text>
        </TouchableOpacity>

        {/* Login Button (Kept outside Bottom Container) */}
        <TouchableOpacity style={styles.button}>
          <Text style={styles.buttonText}>Login</Text>
        </TouchableOpacity>
      </View>

      {/* Bottom Section (Or Login With + Google + Sign Up) */}
      <View style={styles.bottomContainer}>
        {/* Spacing for better layout */}
        <View style={styles.spacing} />

        {/* Divider with "Or Login With" */}
        <View style={styles.dividerContainer}>
          <View style={styles.divider} />
          <Text style={styles.orText}>Or Login With</Text>
          <View style={styles.divider} />
        </View>

        {/* Spacing between Divider & Google Login */}
        <View style={styles.spacing} />

        {/* Google Login Button */}
        <TouchableOpacity style={styles.googleButton} onPress={() => console.log('Google Login Clicked')}>
          <Text style={styles.googleText}>🔵 Google</Text>
        </TouchableOpacity>

        {/* Spacing between Google & Sign Up */}
        <View style={styles.spacing} />

        {/* Sign Up Link */}
        <TouchableOpacity onPress={() => router.push('/(auth)/SignUpScreen')}>
          <Text style={styles.signUpText}>
            Don’t have an account yet? <Text style={styles.signUp}>Sign Up</Text>
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: width * 0.05,
    backgroundColor: '#fff',
  },
  formContainer: {
    flex: 1,
    justifyContent: 'center',
    marginTop: height * 0.1, // ✅ Pushes the Email Address section lower
  },
  label: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 5,
    color: '#000',
  },
  input: {
    height: 45,
    backgroundColor: '#F2F2F2',
    borderRadius: 10,
    paddingHorizontal: 12,
    fontSize: 14,
    marginBottom: 15,
  },
  forgot: {
    color: '#8A2BE2',
    textAlign: 'right',
    fontSize: 14,
    marginBottom: 25,
    fontWeight: '500',
  },
  button: {
    backgroundColor: '#8A2BE2',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 10,
    elevation: 3,
    marginTop: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  bottomContainer: {
    justifyContent: 'flex-end',
    paddingBottom: height * 0.05, // ✅ Ensures spacing is always correct
  },
  spacing: {
    height: height * 0.03, // ✅ Keeps space dynamic
  },
  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  divider: {
    flex: 1,
    height: 1,
    backgroundColor: '#A0A0A0',
  },
  orText: {
    marginHorizontal: 8,
    color: '#000',
    fontSize: 14,
    fontWeight: '500',
  },
  googleButton: {
    backgroundColor: '#D9D9D9',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 20,
  },
  googleText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  signUpText: {
    textAlign: 'center',
    fontSize: 14,
    color: '#000',
  },
  signUp: {
    color: '#8A2BE2',
    fontWeight: 'bold',
  },
});

export default LoginScreen;
