import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Dimensions, Alert } from 'react-native';
import { useRouter } from 'expo-router';
import { auth, GoogleSignin, actionCodeSettings } from '@/lib/firebaseConfig';
import { 
  createUserWithEmailAndPassword, 
  sendEmailVerification, 
  GoogleAuthProvider, 
  signInWithCredential 
} from 'firebase/auth';

const { width, height } = Dimensions.get('window');

const SignUpScreen = () => {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);

  // ✅ Handle Email/Password Sign-Up & Send OTP
  const handleSignUp = async () => {
    if (!email || !password || !confirmPassword) {
      Alert.alert('Error', 'Please fill all fields');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);

      // ✅ Send OTP (Email Verification)
      await sendEmailVerification(userCredential.user, actionCodeSettings);
      
      Alert.alert('Success', 'Check your email for the OTP to verify your account');

      // ✅ Navigate to OTP Screen (Pass Email as Query Param)
      router.push({ pathname: '/(auth)/OTPScreen', params: { email } });
    } catch (error) {
      Alert.alert('Sign Up Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Handle Google Sign-Up
  const handleGoogleSignUp = async () => {
    try {
      await GoogleSignin.hasPlayServices();
      const { idToken } = await GoogleSignin.signIn();
      const googleCredential = GoogleAuthProvider.credential(idToken);
      await signInWithCredential(auth, googleCredential);
      Alert.alert('Success', 'Signed in with Google');
      router.push('/(auth)/home');
    } catch (error) {
      Alert.alert('Google Sign In Failed', error.message);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.formContainer}>
        <Text style={styles.label}>Email Address:</Text>
        <TextInput style={styles.input} placeholder="e.g. hello@email.com" value={email} onChangeText={setEmail} />

        <Text style={styles.label}>Phone Number:</Text>
        <TextInput style={styles.input} placeholder="+65 9XXX XXXX" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />

        <Text style={styles.label}>Password:</Text>
        <TextInput style={styles.input} placeholder="••••••••" value={password} onChangeText={setPassword} secureTextEntry={true} />

        <Text style={styles.label}>Retype Password:</Text>
        <TextInput style={styles.input} placeholder="••••••••" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry={true} />

        <TouchableOpacity style={styles.button} onPress={handleSignUp} disabled={loading}>
          <Text style={styles.buttonText}>{loading ? 'Signing Up...' : 'Submit'}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.bottomContainer}>
        <View style={styles.spacing} />
        <View style={styles.dividerContainer}>
          <View style={styles.divider} />
          <Text style={styles.orText}>Or Sign Up With</Text>
          <View style={styles.divider} />
        </View>
        <View style={styles.spacing} />

        <TouchableOpacity style={styles.googleButton} onPress={handleGoogleSignUp}>
          <Text style={styles.googleText}>🔵 Google</Text>
        </TouchableOpacity>

        <View style={styles.spacing} />
        <TouchableOpacity onPress={() => router.push('/(auth)/LoginScreen')}>
          <Text style={styles.signUpText}>
            Already have an account? <Text style={styles.signUp}>Login</Text>
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: width * 0.05, backgroundColor: '#fff' },
  formContainer: { flex: 1, justifyContent: 'center', marginTop: height * 0.1 },
  label: { fontSize: 14, fontWeight: '600', marginBottom: 5, color: '#000' },
  input: { height: 45, backgroundColor: '#F2F2F2', borderRadius: 10, paddingHorizontal: 12, fontSize: 14, marginBottom: 15 },
  button: { backgroundColor: '#8A2BE2', paddingVertical: 14, alignItems: 'center', borderRadius: 10, elevation: 3, marginTop: 10 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
  bottomContainer: { justifyContent: 'flex-end', paddingBottom: height * 0.05 },
  spacing: { height: height * 0.03 },
  dividerContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 20 },
  divider: { flex: 1, height: 1, backgroundColor: '#A0A0A0' },
  orText: { marginHorizontal: 8, color: '#000', fontSize: 14, fontWeight: '500' },
  googleButton: { backgroundColor: '#D9D9D9', paddingVertical: 14, borderRadius: 10, alignItems: 'center', marginBottom: 20 },
  googleText: { fontSize: 16, fontWeight: '600', color: '#000' },
  signUpText: { textAlign: 'center', fontSize: 14, color: '#000' },
  signUp: { color: '#8A2BE2', fontWeight: 'bold' },
});

export default SignUpScreen;